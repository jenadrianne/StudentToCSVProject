package studentcourseworkresearch;

public class mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
